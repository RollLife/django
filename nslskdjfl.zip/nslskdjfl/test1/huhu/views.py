from django.shortcuts import render
from .models import Seperate
from .models import Dice
import random

# Create your views here.

def index(request):
	seperate = Seperate.objects.all()
	dice = Dice()
	dices1 = random.randrange(1, 7)
	dices2 = random.randrange(1, 7)
	dice.dice1 = dices1
	dice.dice2 = dices2
	dice.save()
	return render(request,'main/index.html', {'seperate':seperate,'dice':dice})

def insert(request):
	road = []
	for i in range(0,150):
		road.append(0)
	mineCount = 0
	count = 0

	while mineCount != 10:
		mine = random.randrange(0, 100)
		if road[mine]==0:
			road[mine] = 1
			mineCount = mineCount + 1

	for a in range(0, 150):
		seperate = Seperate()
		if road[a]==0:
			seperate.seperMine = 0
			seperate.save()
		elif road[a]==1:
			seperate.seperMine = 1
			seperate.save()


	return render(request, 'main/insert.html', {})

def passnext(request):

	return render(request, 'main/passnext.html', {})
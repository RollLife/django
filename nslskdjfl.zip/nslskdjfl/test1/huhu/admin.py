from django.contrib import admin


from .models import PlayerPosition
from .models import Dice
from .models import Seperate
# Register your models here.

admin.site.register(PlayerPosition)
admin.site.register(Dice)
admin.site.register(Seperate)

from django.contrib import admin

from .models import Minegame
# Register your models here.

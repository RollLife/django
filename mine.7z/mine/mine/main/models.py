from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Minegame(models.Model):
	player1Position = models.IntegerField()
	player2Position = models.IntegerField()
	minePosition = models.IntegerField()
	dice1 = models.IntegerField()
	dice2 = models.IntegerField()
	requestPlayer1 = models.IntegerField()
	requestPlayer2 = models.IntegerField()
	gubun = models.IntegerField()
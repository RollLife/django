from django.shortcuts import render
from .models import Minegame
import random

# Create your views here.
def index(request):
	road = []
	for a in range(0,200):
		road.append(0)
	mineCount = 0
	count = 0

	while mineCount != 10:
		mine = random.randrange(0, 100)
		if road[mine]==0:
			road[mine] = 1
			mineCount = mineCount + 1

	for i in range(0,100):
		if road[i]==0:
			Minegame.gubun = 0
		elif road[i]==1:
			Minegame.gubun = 1

	return render(request, 'main/index.html', {})
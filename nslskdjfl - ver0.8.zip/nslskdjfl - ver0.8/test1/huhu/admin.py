from django.contrib import admin


from .models import PlayerPosition
from .models import Dice
from .models import Seperate
from .models import Order
from .models import SeperPlay1
from .models import SeperPlay2
# Register your models here.

admin.site.register(PlayerPosition)
admin.site.register(Dice)
admin.site.register(Seperate)
admin.site.register(Order)
admin.site.register(SeperPlay1)
admin.site.register(SeperPlay2)